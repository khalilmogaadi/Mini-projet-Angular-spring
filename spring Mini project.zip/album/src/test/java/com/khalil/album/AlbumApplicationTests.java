package com.khalil.album;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.khalil.album.entities.Album;
import com.khalil.album.entities.Genre;
import com.khalil.album.repos.AlbumRepository;

@SpringBootTest
class AlbumApplicationTests {
	@Autowired
	private AlbumRepository albumRepository;

	@Test
	public void testCreateAlbum() {
		Album albs = new Album("love always",20.1,new Date());
		albumRepository.save(albs);
		}
	 @Test
	 public void testFindAlbum()
		 {
		 Album a = albumRepository.findById(1L).get(); 
		 System.out.println(a);
		 }
	 @Test
	 public void testUpdateProduit()
		 {
		 Album a = albumRepository.findById(1L).get();
		 a.setPrixAlbum(37.1);
		 albumRepository.save(a);
		 }
	 @Test
	 public void testDeleteAlbum()
		 {
		 albumRepository.deleteById(1L);;
		 }
	  
	 @Test
	 public void testListerTousAlbum()
		 {
		 List<Album> albs = albumRepository.findAll();
		 for (Album a : albs)
		 {
		 System.out.println(a);
		 }
		 }		
	 @Test
	 public void testFindByNomAlbum()
	 {
	 List<Album> albs = albumRepository.findByNomAlbum("Lucille");
	 for (Album a : albs)
	 {
	 System.out.println(a);
	 }
	 }
	 @Test
	 public void testFindByNomAlbumContains ()
	 {
	 List<Album> albs=albumRepository.findByNomAlbumContains("Alcohol and Jake Blues");
	 for (Album a : albs)
	 {
	 System.out.println(a);
	 } }
	 @Test
	 public void testfindByNomPrix()
	 {
			 List<Album> albs = albumRepository.findByNomPrix("Lucille", 100.1);
			 for (Album a : albs)
			 {
			 System.out.println(a);
	 }
	 }
	 @Test
	 public void testfindByGenre()
	 {
			 Genre gen = new Genre();
			 gen.setIdGen(1L);
			 List<Album> albs = albumRepository.findByGenre(gen);
			 for (Album a : albs)
			 {
			 System.out.println(a);
			 }
	 }
	 @Test
	 public void findByGenreIdGen()
	 {
	 List<Album> albs = albumRepository.findByGenreIdGen(1L);
	 for (Album a : albs)
	 {
	 System.out.println(a);
	 }
	  }
	 @Test
	 public void testfindByOrderByNomAlbumAsc()
	 {
			 List<Album> albs = 
		     albumRepository.findByOrderByNomAlbumAsc();
			 for (Album a : albs)
			 {
			 System.out.println(a);
			 }
	 }
	 @Test
	 public void testtrierAlbumNomsPrix()
	 {
			 List<Album> albs = albumRepository.trierAlbumNomsPrix();
			 for (Album a : albs)
			 {
			 System.out.println(a);
			 }
	 }


}
