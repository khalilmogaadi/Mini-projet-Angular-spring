package com.khalil.album.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.khalil.album.entities.Album;
import com.khalil.album.entities.Genre;
import com.khalil.album.repos.AlbumRepository;

@Service
public class AlbumServiceImpl implements AlbumService {
	@Autowired
	AlbumRepository albumRepository;

	@Override
	public Album saveAlbum(Album a) {
		
		return  albumRepository.save(a);

	}

	@Override
	public Album updateAlbum(Album a) {
		// TODO Auto-generated method stub
		return albumRepository.save(a);
	}

	@Override
	public void deleteAlbum(Album a) {
		// TODO Auto-generated method stub
		albumRepository.delete(a);
	}

	@Override
	public void deleteAlbumById(Long id) {
		// TODO Auto-generated method stub
		albumRepository.deleteById(id);
	}

	@Override
	public Album getAlbum(Long id) {
		// TODO Auto-generated method stub
		return  albumRepository.findById(id).get();
	}

	@Override
	public List<Album> getAllAlbums() {
		// TODO Auto-generated method stub
		return albumRepository.findAll();
	}

	@Override
	public List<Album> findByNomAlbum(String nom) {
		return albumRepository.findByNomAlbum(nom);
	}

	@Override
	public List<Album> findByNomAlbumContains(String nom) {
		return albumRepository.findByNomAlbumContains(nom);
	}

	@Override
	public List<Album> findByNomPrix(String nom, Double prix) {
		return albumRepository.findByNomPrix(nom,prix);
	}

	@Override
	public List<Album> findByGenre(Genre genre) {
		// TODO Auto-generated method stub
		return albumRepository.findByGenre(genre);
	}

	@Override
	public List<Album> findByGenreIdGen(Long id) {
		// TODO Auto-generated method stub
		return albumRepository.findByGenreIdGen(id);
	}

	@Override
	public List<Album> findByOrderByNomAlbumAsc() {
		// TODO Auto-generated method stub
		return albumRepository.findByOrderByNomAlbumAsc();
	}

	@Override
	public List<Album> trierAlbumNomsPrix() {
		// TODO Auto-generated method stub
		return albumRepository.trierAlbumNomsPrix();
	}

	
	

}
