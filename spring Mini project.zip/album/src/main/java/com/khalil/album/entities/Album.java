package com.khalil.album.entities;


import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
@Entity
public class Album {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idAlbum;
private String nomAlbum;
private Double prixAlbum;
private Date dateCreation;

@ManyToOne
private Genre genre;

public Genre getGenre() {
	return genre;
}
public void setGenre(Genre genre) {
	this.genre = genre;
}
public Album() {
	super();
	
}
public Album(String nomAlbum, Double prixAlbum, Date dateCreation) {
	super();
	this.nomAlbum = nomAlbum;
	this.prixAlbum = prixAlbum;
	this.dateCreation = dateCreation;
}
public Long getIdAlbum() {
	return idAlbum;
}
public void setIdAlbum(Long idAlbum) {
	this.idAlbum = idAlbum;
}
public String getNomAlbum() {
	return nomAlbum;
}
public void setNomAlbum(String nomAlbum) {
	this.nomAlbum = nomAlbum;
}
public Double getPrixAlbum() {
	return prixAlbum;
}
public void setPrixAlbum(Double prixAlbum) {
	this.prixAlbum = prixAlbum;
}
public Date getDateCreation() {
	return dateCreation;
}
public void setDateCreation(Date dateCreation) {
	this.dateCreation = dateCreation;
}
@Override
public String toString() {
	return "Album [idAlbum=" + idAlbum + ", nomAlbum=" + nomAlbum + ", prixAlbum=" + prixAlbum + ", dateCreation="
			+ dateCreation + "]";
}

}
