package com.khalil.album.service;

import java.util.List;

import com.khalil.album.entities.Album;
import com.khalil.album.entities.Genre;

public interface AlbumService {
	Album saveAlbum(Album a);
	Album updateAlbum(Album a);
	void deleteAlbum(Album a);
	 void deleteAlbumById(Long id);
	 Album getAlbum(Long id);
	List<Album> getAllAlbums();
	List<Album> findByNomAlbum(String nom);
	List<Album> findByNomAlbumContains(String nom);
	List<Album> findByNomPrix (String nom, Double prix);
	List<Album> findByGenre (Genre genre);
	List<Album> findByGenreIdGen(Long id);
	List<Album> findByOrderByNomAlbumAsc();
	List<Album> trierAlbumNomsPrix();

}
